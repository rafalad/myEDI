﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Windows.Forms;
using System.IO;
using EDISupportTool;

namespace myEDI
{

	class Resources
	{
        public static string listBoxMessageDris = string.Empty; //jezeli foldery nie zostaly utworzone (bo wczesnij istnialy) nie zwracaj komunikatu.
       // public static string versionMessage = string.Empty;


        public void Dirs()
        {
            if (Directory.Exists(@"C:\EDI") ||
                Directory.Exists(@"C:\EDI\Templates") ||
                Directory.Exists(@"C:\DEPLOYMENTS\") ||
                Directory.Exists(@"C:\DEPLOYMENTS\DEPLOY") ||
                Directory.Exists(@"C:\DEPLOYMENTS\Reports") ||
                Directory.Exists(@"C:\DEPLOYMENTS\Reports\QA") ||
                Directory.Exists(@"C:\DEPLOYMENTS\Reports\PROD") ||
                Directory.Exists(@"C:\DEPLOYMENTS\Resources"))
            {

            }
            else
            {
                Directory.CreateDirectory(@"C:\EDI");
                Directory.CreateDirectory(@"C:\EDI\Templates");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\DEPLOY");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\Reports");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\Reports\QA");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\Reports\PROD");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\Resources");

                listBoxMessageDris = "[" + DateTime.Now.ToString("HH:mm:ss") + @"] New dir resources have been created.";
            }
        }

        public void PrepareDirs()
        {
            if (System.IO.Directory.Exists(@"C:\DEPLOYMENTS\Resources"))
            {
                try
                {
                    System.IO.Directory.Delete(@"C:\DEPLOYMENTS\Resources", true);
                }

                catch (System.IO.IOException e)
                {
                    MessageBox.Show(e.Message, "myEDI", MessageBoxButtons.OK, MessageBoxIcon.Error));
                }
            }

            if (System.IO.Directory.Exists(@"C:\DEPLOYMENTS\Reports"))
            {
                try
                {
                    System.IO.Directory.Delete(@"C:\DEPLOYMENTS\Reports", true);
                }

                catch (System.IO.IOException e)
                {
                    MessageBox.Show(e.Message, "myEDI", MessageBoxButtons.OK, MessageBoxIcon.Error));
                }
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\Reports");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\Reports\QA");
                Directory.CreateDirectory(@"C:\DEPLOYMENTS\Reports\PROD");
            }
        }

        public void LogToFTP() //Metoda zapisujaca logi do pliku log.txt na serwerze FTP
        {
            LoginDSV login = new LoginDSV();

            string date = DateTime.Today.ToString("dd-MM-yyyy");
            string time = DateTime.Now.ToString("HH:mm:ss");
            string who = login.Login();
            string ver = "v" + Application.ProductVersion;

            string input = "[" + date + "][" + time + "][" + who + "][" + ver + "]\n";

            byte[] data = Encoding.ASCII.GetBytes(input);

            try
            {
                FtpWebRequest request = (FtpWebRequest)WebRequest.Create("ftp://files.000webhost.com/myedi/log.txt");
                request.Credentials = new NetworkCredential("ediapp", "w8EtQdvNMJ8vXbt");
                request.Method = WebRequestMethods.Ftp.AppendFile;
                
                Stream requestStream = request.GetRequestStream();
                requestStream.Write(data, 0, data.Length);
                requestStream.Close();
                FtpWebResponse response = (FtpWebResponse)request.GetResponse();
                response.Close();
            }
            catch
            {
            }
        }
        
        public string CheckVersion()
        {
            WebClient client = new WebClient();
            string versionMessage;

            try
            {
                if (client.DownloadString("https://pastebin.com/raw/qiJ05NWB").Contains("1.1.0.7"))
                {
                        versionMessage = "[ you're using the latest myEDI version. ]";                  
                }
                else
                {
                    versionMessage = "[ a new version is available ]"; 
                }
            }
            catch
            {
                versionMessage = "[ failed to get the version info ]";
            }

            return versionMessage;
        }
    }
}
