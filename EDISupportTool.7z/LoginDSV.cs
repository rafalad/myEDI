﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Globalization;
using System.IO;
using Microsoft.Office.Interop.Excel;
using _Excel = Microsoft.Office.Interop.Excel;

namespace EDISupportTool
{
	public class LoginDSV
	{
		public string Login()
		{
			string credentials = SystemInformation.UserName;

			try
			{
				int dot = credentials.IndexOf("."); //wyliczam kropke

				string name = credentials.Remove(dot);
				string lastname = credentials.Substring(dot + 1);

				string login = name.Remove(2) + lastname.Remove(2);
				return login.ToLower();
			}

			catch //w przypadku bledu konwersji zwroc cala nazwe uzytkownika
			{
				return SystemInformation.UserName;
			}
		}

		public void AddLog()
		{
			string logPath = @"\\dsvcorp.sharepoint.com@SSL\DavWWWRoot\teams\EDISupport\Shared Documents\EDI Support Documents\Support Documents\myEDI\log.xlsx";
			Excel excel = new Excel(logPath, 1);

			int i = 0;
			int k = 1;

			excel.ReadCell(0, 0);
			excel.ReadCell(1, 1);

			string date = DateTime.Today.ToString("dd-MM-yyyy");
			string time = DateTime.Now.ToString("HH:mm:ss");
			string who = Login();
			string ver = "v"+ System.Windows.Forms.Application.ProductVersion;

			string content = "[" + date + "][" + time + "][" + who + "][" + ver + "]";

			try
			{
				excel.WriteToCell(k++, 0, content);
				//string logPath = @"\\dsvcorp.sharepoint.com@SSL\DavWWWRoot\teams\EDISupport\Shared Documents\EDI Support Documents\Support Documents\myEDI\log.xlsx";
				//using (StreamWriter outputFile = new StreamWriter(logPath, true))
				//{
				//	if (!logPath.Contains(" "))
				//	{
				//		outputFile.WriteLine("[" + date + "][" + time + "][" + who + "][" + ver + "]");
				//	}
				//}
				excel.Save();
				excel.Close();
			}

			catch
			{

				//MessageBox.Show("You are probably using the app outside of the DSV network. Log in to the network to be able to take full advantage of it. Thanks!", "myEDI", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}

		}
	}

	public class Excel
	{
		string path = "";
		_Application excel = new _Excel.Application();
		Workbook wb;
		Worksheet ws;

		public Excel(string path, int sheet)
		{
			if (path == "blank")
			{

			}
			else
			{
				this.path = path;
				wb = excel.Workbooks.Open(path);
				ws = wb.Worksheets[sheet];
			}
		}

		public string ReadCell(int i, int j)
		{
			//
			i++;
			j++;
			if (ws.Cells[i, j].Value2 != null)
				return ws.Cells[i, j].Value2;
			else
				return "";
		}

		public void WriteToCell(int i, int j, string s)
		{
			//ws.Cells[1, 1].Column.
			//ws.Cells.Borders.
			//ws.Cells.EntireColumn.AutoFit(); // dostosowanie kalumny szerokoc
			//ws.Columns.AutoFitContents();
			//ws.Cells.EntireRow.BorderAround2();
			//ws.Cells[1, 1].EntireRow.Font.Bold = true;
			//.Style.EntireColumn.AutoFit();
			i++;
			j++;
			ws.Cells[i, j].Value2 = s;
			//ws.Cells.FormulaHidden = false;

		}

		public void Save()
		{
			wb.Save();
		}
		public void SaveAs(string path)
		{
			wb.SaveAs(path);
		}
		public void Close()
		{
			wb.Close();
			excel.Quit();
		}
		public void KillSpecificExcelFileProcess(string excelFileName)
		{
			var processes = from p in Process.GetProcessesByName(excelFileName)
							select p;

			foreach (var process in processes)
			{
				if (process.MainWindowTitle == excelFileName)
					process.Kill();
			}
		}
	}
}
